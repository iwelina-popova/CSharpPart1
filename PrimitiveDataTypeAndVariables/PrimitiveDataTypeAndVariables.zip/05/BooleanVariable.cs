﻿/* Declare a Boolean variable called isFemale and assign an appropriate value corresponding to your gender.
Print it on the console. */

using System;

    class BooleanVariable
    {
        static void Main(string[] args)
        {
            bool isFemale = true;
            Console.WriteLine("Am I a female?\n" + isFemale);
            Console.Read();
        }
    }

